'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
target=14
li=[1,2,3,4,5,6]
li1=[7,8,9,10,11]
for i in li:
    x=0
    if i+li1[x]==target:
        print(i,li1[x])
x+=1
    
