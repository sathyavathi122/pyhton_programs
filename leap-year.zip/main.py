'''/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/'''
year=int(input("enter the year"))
if((year % 400 == 0) or  (year % 100 != 0) and  (year % 4 == 0)): 
    print("leap year")
else:
    print("not a leap year")