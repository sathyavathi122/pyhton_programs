/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************
* /**/

#include<stdio.h>
int main()
{
    int n ,rev=0,dig;
    printf("enter number");
    scanf("%d",&n);
    while(n>0)
    {
    dig=n%10;
    rev=rev*10+dig;
    n=n/10;
    }
    printf("reversed number is : %d",rev);
    return 0;
}