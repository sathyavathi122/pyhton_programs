'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
pos=-1
def binarysearch(arr,n):
    first=0
    last=len(arr)-1
    while first<=last:
        mid=(first+last)//2
        if arr[mid]==n:
           globals()['pos']=mid
           return True
        else:
            if arr[mid]<n:
                first=mid
            else:
                last=mid
arr=[1,2,4,3,5,3,5]
n=4
if binarysearch(arr,n):
    print("found at ",pos+1)
else:
    print("not found")