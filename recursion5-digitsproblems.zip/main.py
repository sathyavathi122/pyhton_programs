'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

def countdigits(num,li):
    if num==len(li)-1:
        return num
    else:
        num+=1 
        print(li[num])
        return countdigits(num,li)
li=list(map(int,input("enter the number").split()))
countdigits(-1,li)
print("the total number digits are:",len(li))