'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


a=input("enter the name")
for st in a:
    if st==st.upper():
      st=st.lower()
    elif st==st.lower():
      st=st.upper()
    else:
      print()
print(a)      '''
a=input()
for st in a:
    b=st.upper()
    print(b)
    