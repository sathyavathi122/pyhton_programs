'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def maxsumsliding(arr,k):
    if len(arr)<k:
        return -1
    sum1=0
    sum2=sum(arr(:k))
    sum1=sum2
    for i in range(len(arr)-k):
        sum2=sum2-arr[i]+arr[i+k]
        sum1=max(sum1,sum2)
    return(sum1)
    
        