'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
candles=int(input("enter the number of candles"))
print("sales must be less then candles")
sales=int(input("enter the number of sales"))
reming=candles-sales
castamor=int(input("castamor need"))
if reming<castamor:
    print("INVALID")
elif reming>castamor:
    total=reming-castamor
    print(total)
else:
    print("INVALID")

