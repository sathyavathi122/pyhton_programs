'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
num=int(input())
if num==0:
    print("invalid value")
for i in range(,num):
    if num%i==0:
        print("the num is not a prime")
        break
    else:
        print("the given num is prime")