'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
lis=[]
lis1=[]
for i in range(5):
    for i in range(2):
        x,y=list(map(int,input("enter the values").split()))
        lis.append(x)
        lis.append(y)
        if len(lis)>2:
            lis1.append(x)
            lis1.append(y)
            print(lis,lis1)
            if lis[0]==lis1[0] and lis[1]==lis1[1]:
                print("your chioce is already existed")
                break
            else:
                lis.clear()
                lis1.clear()
                print(lis,lis1)
        
        