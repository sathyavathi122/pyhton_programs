'''/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/'''
list=[1,2,3,4,5]
list1=[]
for i in range(1,5+1):
    (list.remove(i))
    sum(list)
    list1.append(sum(list))
    list.append(i)
print(max(list1),min(list1),end="")

