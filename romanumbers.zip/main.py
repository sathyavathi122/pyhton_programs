'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def romannum():
    roman={"I":1,"v":5,"x":10,"L":50,"C":100,"D":500,"M":1000}
    res=0
    for i in range(len(r)):
        if i+1 <len(r) and roman[r[i]<roman[r[i+1]]]:
            res-=roman[r[i]]
        else:
            res+=roman[r[i]]
    return res
r=[I,I,I]
print(romannum(r))