'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def maxsubarr(arr):
    maxsum=float('-inf')
    for i in range(len(arr)):
        currentsum=0
        for j in range(i,len(arr)):
            currentsum+=arr[j]
            maxsum=max(currentsum,maxsum)
        return maxsum
arr=[1,2,4,3,-4]
print(maxsubarr(arr))
 
            