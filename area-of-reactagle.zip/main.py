'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


class rectangle():
    def __init__(self,a,b):
     self.a=a
     self.b=b
    def length(self):
     return self.a*self.b
d=rectangle(3,4)
print(d.length())'''
class rectangle():
    def data(self):
        rectangle.a=int(input("enter the a value"))
        rectangle.b=int(input("enter the b value"))
        print("the length of a",rectangle.a)
        print("the breath of b",rectangle.b)
    def area(self):
        return rectangle.a*rectangle.b
c=rectangle()
print(c.data())
print(c.area())



    
    