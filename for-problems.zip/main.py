'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
arr=[]
li1=[1,-5,4,3]
li2=[3,7,2,8]
for i in range(len(li1)):
    for j in range(len(li2)):
        s=li1[i]+li2[j]
        arr.append(s)
if max(arr)==s:
    print(li1[i],li2[j])
print(max(arr))
print(arr)