'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.
=
n=int(input())
list1=[]
for i in range(n):
 x=int(input())
 list1.append(x)
a=max(list1)
list1.remove(a)
b=max(list1)
print("the runuptime",b)'''
n=int(input())
a=list(map(int,input().split()))
b=list(set(a))
b.sort()
print(b[-2])
