'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

T=int(input())
list1=[]
for i in range(T):
    size=len(list1))
    num=int(input())
    list1.append(num)
str(list1)
a=' '.join(list1)
print(a[:-1])'''
t=int(input())
for i in range(t):
    x=int(input())
    list=[]
    for i in range(x):
        y=int(input())
        list.append(y)
    for i in range(x-1,-1,-1):
        print(list[i],end=" ")

