'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
print("counting of itaration")
def counting():
  count=0
  for i in range(1990,2025):
    print(i)
    count+=1
    print(count)
a=counting() 
print("counting of itaration without funtion")
count1=0
for i in range(1990,2025):
 print(i)
 count1+=1
 print(count1)