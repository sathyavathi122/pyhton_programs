'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def bubble_sort(lis):
    for i in range(0,len(lis)):
        mim=i
        for j in range(i+1,len(lis)):
            if lis[mim]>lis[j]:
                temp=lis[mim]
                lis[mim]=lis[j]
                lis[j]=temp
        return lis
lis=list(map(int,input("enter the list").split()))
print(bubble_sort(lis))