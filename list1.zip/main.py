'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
list1=[]
list2=[]
list3=[]
for i in range(0,11):
    rand=int(input("enter the number"))
    list1.append(rand)
    if rand%2==0:
        list2.append(rand)
    else:
       list3.append(rand)
print(list1)
print(list2)
print(list3)