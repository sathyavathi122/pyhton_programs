'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
tupl=("ramesh",3,33,"rudri")
print(tupl.count("ramesh"))
a=tupl[1]
print(a)
tupl1=(1,2,3,4,4)
print(max(tupl1))
print(min(tupl1))
print(sum(tupl1))
tupl1.sort()
print(tupl1)
for i in tupl1:
    print(i)
