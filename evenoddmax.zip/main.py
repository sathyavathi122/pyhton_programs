'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def compare(a,b):
    if a%2==0 and b%2==0:
       print(min(a,b))
    else:
       print(max(a,b))
a=int(input())
b=int(input())
obj=compare(a,b)
