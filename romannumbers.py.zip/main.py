'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
def romon_numbers(num):
    if num>3000:
        print("the value must be less then 3000")
        return
    value=[1000,900,500,400,100,90,50,40,10,9,5,4,1]
    symbols=["M","CM","D","CD","D","XD","L","XL","X","IX","V","IV","I"]
    romon=" "
    i=0
    while num>0:
        div=num//value[i]
        num=num%value[i]
        while num:
            romon=romon+symbols[i]
            div=div-1
        i=i+1
    return romon
num=int(input())
print(romon_numbers(num))

    